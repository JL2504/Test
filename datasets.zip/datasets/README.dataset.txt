# 107 Assignment > 2025-01-04 3:42pm
https://universe.roboflow.com/diploma-wuvsd/107-assignment

Provided by a Roboflow user
License: CC BY 4.0

